package com.qsp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.entity.Account;

public interface AccountRepository extends JpaRepository<Account,String>{

}
