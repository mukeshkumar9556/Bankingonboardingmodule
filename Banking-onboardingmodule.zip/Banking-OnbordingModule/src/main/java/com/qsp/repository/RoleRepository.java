package com.qsp.repository;

 
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.sequrity.model.ERole;
import com.qsp.sequrity.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
     
    Optional<Role> findByName(ERole name);
}
