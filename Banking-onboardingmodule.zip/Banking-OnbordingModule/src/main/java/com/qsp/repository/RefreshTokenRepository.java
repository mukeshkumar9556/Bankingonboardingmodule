package com.qsp.repository;

 

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.sequrity.model.RefreshToken;
import com.qsp.sequrity.model.User;


public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
Optional<RefreshToken> findByToken(String token);
int deleteByUser(User user);
}