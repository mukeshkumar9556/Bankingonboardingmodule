package com.qsp.sequrity.model;



import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

import com.twilio.rest.chat.v1.service.User;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "refresh_tokens")
public class RefreshToken {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;


@OneToOne
@JoinColumn(name = "user_id", referencedColumnName = "id")
private com.qsp.sequrity.model.User user;


@Column(nullable = false, unique = true)
private String token;


@Column(nullable = false)
private Instant expiryDate;
}