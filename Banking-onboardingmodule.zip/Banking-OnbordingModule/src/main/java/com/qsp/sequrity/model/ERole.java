package com.qsp.sequrity.model;

public enum ERole {

	
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN
}

