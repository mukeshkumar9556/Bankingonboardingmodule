package com.qsp.sequrity.jwtutil;
 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.qsp.repository.UserRepository;
import com.qsp.sequrity.model.User;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;


        @Override
        public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
            User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
            
            System.out.println("Loaded user: " + user.getUsername() + ", password: " + user.getPassword());

            System.out.println(user);
            return new org.springframework.security.core.userdetails.User(
                    user.getUsername(),
                    user.getPassword(),   // <-- must be the encoded password
                    user.getRoles().stream()
                        .map(role -> new SimpleGrantedAuthority(role.getName().name()))
                        .toList()
            );
            
            
            
        }
    }



