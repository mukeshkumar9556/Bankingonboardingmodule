package com.qsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingOnbordingModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
